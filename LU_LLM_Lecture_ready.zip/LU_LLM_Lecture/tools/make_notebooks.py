# -*- coding: utf-8 -*-
"""Generate the student exercise notebook and its solution.

Numbers are the lecture's own: the two-token toy from the "Your turn" slide,
and the score matrix whose masked softmax reproduces the 46 % / 28 % on the
Softmax slide.
"""
import json, copy

NB = {"cells": [], "metadata": {
    "kernelspec": {"display_name": "Python 3", "language": "python",
                   "name": "python3"},
    "language_info": {"name": "python", "version": "3"}},
    "nbformat": 4, "nbformat_minor": 5}


def md(src):
    return {"cell_type": "markdown", "metadata": {},
            "source": src.strip("\n").split("\n")}


def code(src):
    return {"cell_type": "code", "execution_count": None, "metadata": {},
            "outputs": [], "source": src.strip("\n").split("\n")}


# ----------------------------------------------------------------- shared --
SETUP = '''
import numpy as np

np.set_printoptions(precision=3, suppress=True)

# ---- the toy from the lecture -------------------------------------------
# two tokens of the same sentence, two dimensions so you can do it by hand
e1 = np.array([1.0, 2.0])      # token 1
e2 = np.array([0.0, 2.0])      # token 2   <- the one on the exercise slide

q  = np.array([2.0, 2.0])      # the query we are asking with

W_K = np.array([[0.0, 1.0],    # the learned key matrix
                [1.0, 0.0]])
W_V = np.array([[1.0,  1.0],   # the learned value matrix
                [1.0, -1.0]])

d_k = 2                        # the head width, so the scaling is sqrt(2)
'''

CHECK = '''
def check(name, got, want, tol=1e-2):
    if got is None:
        print(f"  ----   {name:<14} not filled in yet")
        return False
    got = np.atleast_1d(np.asarray(got, dtype=float))
    want = np.atleast_1d(np.asarray(want, dtype=float))
    ok = got.shape == want.shape and np.allclose(got, want, atol=tol)
    print(("  OK   " if ok else "  WRONG") + f"  {name:<14} "
          f"you: {np.round(got, 3)}   expected: {np.round(want, 3)}")
    return ok

print("Part A")
results = [
    check("k2",    k2,    [2.0, 0.0]),
    check("s",     s,     [4.243, 2.828]),
    check("alpha", alpha, [0.805, 0.195]),
    check("v1",    v1,    [3.0, -1.0]),
    check("v2",    v2,    [2.0, -2.0]),
    check("delta", delta_e, [2.805, -1.195]),
]
print()
if all(results):
    print("all correct")
else:
    print("not finished - fill in the lines marked ---- and fix any marked WRONG")
'''

SENTENCE = '''
TOKENS = ["Known", "allergy", "to", "penicillin", ";",
          "treated", "with", "ceftriaxone"]

# The scaled scores s[t, i] for the sentence, exactly as on the lecture's grid
# (rows = the token asking, columns = the token answering).
S = np.array([
    [ 1.2, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4, -0.4],
    [ 1.1,  1.2, -0.4,  2.6, -0.4, -0.4, -0.4, -0.4],
    [-0.4,  0.9,  1.2, -0.4, -0.4, -0.4, -0.4, -0.4],
    [ 0.7,  2.2, -0.4,  1.2, -0.4, -0.4, -0.4, -0.4],
    [-0.4, -0.4, -0.4, -0.4,  1.2, -0.4, -0.4, -0.4],
    [-0.4,  1.3, -0.4,  1.1, -0.4,  1.2, -0.4, -0.4],
    [-0.4, -0.4, -0.4, -0.4, -0.4,  1.4,  1.2, -0.4],
    [-0.4,  2.4, -0.4,  2.9, -0.4,  1.2,  0.6,  1.2],
])
'''

# ============================================================== STUDENT ====
s_cells = [
md('''
# Self-Attention by hand, then in numpy

**Fundamentals of Large Language Models** — *Next-Word Prediction and Self-Attention*
Vorlesung *Datensynthese und Sprachmodelle in der Medizin*

This is the exercise from the **"Your turn"** slide. Do it on paper first — it is four
short lines — then fill in the `TODO`s here and let the notebook check you.

Only `numpy` is needed. Nothing is downloaded; everything runs offline.
'''),
md('''
## Setup — the toy from the lecture

Two tokens, two dimensions, the same learned matrices you saw on the slide.
'''),
code(SETUP),
md('''
## Part A — the four lines from the slide

> **GIVEN** `q = (2, 2)`,  `W_K = [[0,1],[1,0]]`,  `W_V = [[1,1],[1,-1]]`,  `e2 = (0, 2)`
>
> **FIND**, in order: `k2`  →  `s`  →  `alpha`  →  `delta_e`

### TODO 1 — the keys

Each token advertises itself with a key, `k = W_K e`.
'''),
code('''
k1 = W_K @ e1          # done for you - token 1
k2 = None              # TODO 1: the key for token 2

print("k1 =", k1)
print("k2 =", k2)
'''),
md('''
### TODO 2 — the scores

How well does the query match each key? A dot product, divided by `sqrt(d_k)` so the
size of the score does not grow with the width of the head.

$$s_{i} = \\frac{q \\cdot k_i}{\\sqrt{d_k}}$$
'''),
code('''
# TODO 2: build the array of the two scaled scores, in order [s1, s2]
s = None

print("s =", s)
'''),
md('''
### TODO 3 — softmax

Turn the two scores into attention weights that are positive and sum to exactly 1.

$$\\alpha_i = \\frac{\\exp(s_i)}{\\sum_j \\exp(s_j)}$$

*Hint: subtract `s.max()` before exponentiating. It changes nothing mathematically and
it stops `exp` overflowing — every real implementation does this.*
'''),
code('''
def softmax(x):
    # TODO 3a: return the softmax of the 1-D array x
    return None

alpha = None           # TODO 3b: apply it to s

print("alpha =", alpha)
print("sums to", None if alpha is None else alpha.sum())
'''),
md('''
### TODO 4 — the values, and the update

Attention does not output a weight. It outputs a **vector**: the value vectors mixed in
the proportions `alpha`.

$$v_i = W_V e_i \\qquad \\Delta e = \\sum_i \\alpha_i \\, v_i$$
'''),
code('''
v1 = None              # TODO 4a
v2 = None              # TODO 4b
delta_e = None         # TODO 4c: the weighted sum

print("v1 =", v1)
print("v2 =", v2)
print("delta_e =", delta_e)
'''),
md('''
### Check yourself

Run this once you have filled in all four.
'''),
code(CHECK),
md('''
**What the answer means.** Token 2 gets about 20 % of the attention and token 1 about
80 %, even though both are in the same sentence. Token 2's key points away from the
query — and attention is a *similarity*, not a distance.
'''),
md('''
## Part B — the whole sentence

Same arithmetic, eight tokens instead of two. These are the scores from the grid in the
lecture.
'''),
code(SENTENCE),
md('''
### TODO 5 — mask, then normalise

Two things to do:

1. **Mask** — a token may not look at tokens that come *after* it. Set those scores to
   `-inf` **before** the softmax, so they become exactly zero after it.
2. **Softmax each row**, so every row is a probability distribution over the tokens so
   far.
'''),
code('''
def attention_pattern(S):
    """S -> the masked, row-normalised attention pattern."""
    n = S.shape[0]
    M = S.copy()
    # TODO 5a: set the strictly-upper triangle of M to -np.inf
    #          (hint: np.triu_indices(n, 1))

    # TODO 5b: softmax each ROW of M and return it
    return None


A = attention_pattern(S)
A
'''),
code('''
if A is not None:
    t = TOKENS.index("ceftriaxone")
    print('query = "ceftriaxone"\\n')
    for tok, w in zip(TOKENS, A[t]):
        bar = "#" * int(round(w * 40))
        print(f"  {tok:<12} {w:5.1%}  {bar}")
    print(f"\\n  row sums to {A[t].sum():.3f}")
    print("\\nExpected from the lecture: penicillin 46 %, allergy 28 %.")
'''),
md('''
**The point of the whole lecture, in one number.** The query is *"ceftriaxone"*, and
almost half its attention lands on *"penicillin"* — nine tokens back. That is the reach
an n-gram does not have.
'''),
md('''
## Part C — from prediction to synthesis *(optional)*

The closing slide: the same machinery run forward writes text. Here is the whole
generation loop, in eight lines.

`temperature` is the slider: divide the scores by `T` before the softmax. Low `T`
repeats, high `T` invents.
'''),
code('''
VOCAB  = ["temperature", "pulse", "weight"]
LOGITS = np.array([2.0, 1.0, 0.0])      # the toy from the temperature slide

def sample_once(logits, T=1.0, rng=None):
    rng = rng or np.random.default_rng(0)
    p = np.exp((logits - logits.max()) / T)
    p = p / p.sum()
    return VOCAB[rng.choice(len(VOCAB), p=p)], p

for T in (0.3, 1.0, 2.5):
    rng = np.random.default_rng(7)
    draws = [sample_once(LOGITS, T, rng)[0] for _ in range(12)]
    _, p = sample_once(LOGITS, T)
    print(f"T = {T:>3}   p = {np.round(p, 2)}   ->  " + " ".join(draws[:6]))
'''),
md('''
**Try it:** turn `T` up and run the cell again. The same model, the same prompt — a
different note every time. That is data synthesis, and it is also why a generated note
has to be *checked* rather than trusted.
''')]

# ============================================================= SOLUTION ====
sol = copy.deepcopy(s_cells)
FILL = {
    'k2 = None              # TODO 1: the key for token 2':
        'k2 = W_K @ e2         # the key for token 2',
    '# TODO 2: build the array of the two scaled scores, in order [s1, s2]\ns = None':
        's = np.array([q @ k1, q @ k2]) / np.sqrt(d_k)',
    '    # TODO 3a: return the softmax of the 1-D array x\n    return None':
        '    z = np.exp(x - x.max())    # shift for numerical stability\n'
        '    return z / z.sum()',
    'alpha = None           # TODO 3b: apply it to s':
        'alpha = softmax(s)',
    'v1 = None              # TODO 4a':
        'v1 = W_V @ e1',
    'v2 = None              # TODO 4b':
        'v2 = W_V @ e2',
    'delta_e = None         # TODO 4c: the weighted sum':
        'delta_e = alpha[0] * v1 + alpha[1] * v2',
    '    # TODO 5a: set the strictly-upper triangle of M to -np.inf\n'
    '    #          (hint: np.triu_indices(n, 1))\n\n'
    '    # TODO 5b: softmax each ROW of M and return it\n    return None':
        '    M[np.triu_indices(n, 1)] = -np.inf\n'
        '    Z = np.exp(M - M.max(axis=1, keepdims=True))\n'
        '    return Z / Z.sum(axis=1, keepdims=True)',
}
for c in sol:
    if c["cell_type"] != "code":
        continue
    src = "\n".join(c["source"])
    for a, b in FILL.items():
        src = src.replace(a, b)
    c["source"] = src.split("\n")
sol[0]["source"] = ("\n".join(sol[0]["source"])
                    .replace("# Self-Attention by hand, then in numpy",
                             "# Self-Attention by hand, then in numpy "
                             "— SOLUTION")
                    .replace("Do it on paper first — it is four",
                             "**This is the worked solution.** Do the exercise "
                             "first; it is four")).split("\n")

for name, cells in (("notebooks/llm_student_exercise.ipynb", s_cells),
                    ("notebooks/llm_solution.ipynb", sol)):
    nb = dict(NB); nb["cells"] = cells
    with open(name, "w", encoding="utf-8") as f:
        json.dump(nb, f, ensure_ascii=False, indent=1)
    print("wrote", name, "-", len(cells), "cells")
